# Thepkub RC (v2)
แอปควบคุมรถ ESP32 ผ่าน Bluetooth Classic (SPP) — โปรโตคอลตรงกับโค้ด ESP32 ของคุณ (D / N / T / P)

## สร้าง APK
**วิธีที่ 1 (ง่ายสุด):** อัปโฟลดโฟลเดอร์นี้ขึ้น GitHub → แท็บ Actions → Build APK → ดาวน์โหลด ThepkubRC-apk
**วิธีที่ 2:** เปิดใน Android Studio → Build > Build APK(s)
