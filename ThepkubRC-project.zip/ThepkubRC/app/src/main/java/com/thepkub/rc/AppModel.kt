package com.thepkub.rc

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.speech.SpeechRecognizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

class AppModel(private val app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("rc", Context.MODE_PRIVATE)
    val link = BtLink(app, viewModelScope)

    var speed by mutableIntStateOf(prefs.getInt("speed", 70)); private set
    var dps by mutableFloatStateOf(prefs.getFloat("dps", 180f)); private set   // องศา/วินาที ตอนหมุนอยู่กับที่
    var invL by mutableStateOf(prefs.getBoolean("invL", false)); private set
    var invR by mutableStateOf(prefs.getBoolean("invR", true)); private set
    var heard by mutableStateOf(""); private set
    var plan by mutableStateOf(listOf<Cmd>()); private set
    var active by mutableIntStateOf(-1); private set
    var running by mutableStateOf(false); private set
    var listening by mutableStateOf(false); private set

    private var jx = 0f
    private var jy = 0f
    private var last = ""
    private var job: Job? = null
    private val voice = Voice(app, ::onHeard, { heard = it }, { heard = it; listening = false })

    init {
        // ส่งค่าจอยสติ๊ก 25 ครั้ง/วินาที เฉพาะเมื่อค่าเปลี่ยน
        viewModelScope.launch {
            while (true) {
                delay(40)
                if (link.state.value != LinkState.CONNECTED) { last = ""; continue }
                if (running) { if (jx != 0f || jy != 0f) job?.cancel(); continue }
                val line = mixLine()
                if (line != last) { link.send(line); last = line }
            }
        }
    }

    private fun curve(v: Float) = v * (0.35f + 0.65f * abs(v))

    private fun mixLine(): String {
        val y = curve(jy); val x = curve(jx)
        var l = y + x; var r = y - x
        val m = maxOf(abs(l), abs(r))
        if (m > 1f) { l /= m; r /= m }
        val a = (l * speed).roundToInt(); val b = (r * speed).roundToInt()
        return "D,$a,$b,$a,$b"
    }

    fun joy(x: Float, y: Float) { jx = x; jy = y }

    fun setSpeed(v: Int) { speed = v.coerceIn(20, 100); prefs.edit().putInt("speed", speed).apply() }
    fun setDps(v: Float) { dps = v; prefs.edit().putFloat("dps", v).apply() }
    fun setInv(l: Boolean, r: Boolean) {
        invL = l; invR = r
        prefs.edit().putBoolean("invL", l).putBoolean("invR", r).apply()
        link.send("N,${if (l) 1 else 0},${if (r) 1 else 0},0,0")
    }
    fun test(n: Int) { link.send("T,$n") }

    fun estop() {
        job?.cancel(); jx = 0f; jy = 0f
        link.drive(0, 0); link.drive(0, 0); last = ""
    }

    fun toggleListening() {
        if (listening) { stopListening(); return }
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            heard = "ต้องอนุญาตไมโครโฟนก่อน"; return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(app)) { heard = "เครื่องนี้ไม่มีบริการรู้จำเสียง (ติดตั้ง Google)"; return }
        voice.start(); listening = true; heard = "กำลังฟัง…"
    }

    fun stopListening() { voice.stop(); listening = false }

    fun onHeard(text: String) {
        heard = text
        val cmds = VoiceParser.parse(text)
        if (cmds.isEmpty()) return
        val f = cmds[0]
        if (f.kind == Kind.STOP && f.value == null) { estop(); plan = cmds; return }
        run(cmds)
    }

    fun run(cmds: List<Cmd>) {
        if (link.state.value != LinkState.CONNECTED) return
        job?.cancel()
        job = viewModelScope.launch {
            running = true; plan = cmds
            try {
                var s = speed
                var deadline = System.nanoTime()
                for ((i, c) in cmds.withIndex()) {
                    active = i
                    link.lcd(c.lcd())
                    fun turnSec() = if (c.deg || c.value == null) (c.value ?: 90.0) / dps else c.value!!
                    val sec: Double = when (c.kind) {
                        Kind.FWD -> { link.drive(s, s); c.value ?: 1.0 }
                        Kind.BACK -> { link.drive(-s, -s); c.value ?: 1.0 }
                        Kind.LEFT -> { link.drive(-s, s); turnSec() }
                        Kind.RIGHT -> { link.drive(s, -s); turnSec() }
                        Kind.STOP -> { link.drive(0, 0); c.value ?: break }
                        Kind.SPEED -> { s = (c.value ?: 70.0).toInt().coerceIn(20, 100); setSpeed(s); 0.0 }
                    }
                    deadline += (sec * 1_000_000_000L).toLong()
                    val ms = (deadline - System.nanoTime()) / 1_000_000
                    if (ms > 0) delay(ms)
                }
            } finally {
                link.drive(0, 0); link.drive(0, 0)
                link.lcd("READY", "")
                running = false; active = -1; last = ""
            }
        }
    }

    override fun onCleared() { voice.stop(); estop(); link.disconnect() }
}
