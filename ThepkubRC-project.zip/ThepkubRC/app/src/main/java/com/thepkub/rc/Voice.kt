package com.thepkub.rc

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** ฟังเสียงต่อเนื่อง (เริ่มฟังใหม่อัตโนมัติ) */
class Voice(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onPartial: (String) -> Unit,
    private val onFatal: (String) -> Unit
) {
    private val h = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var on = false

    fun start() { on = true; make(); listen() }
    fun stop() { on = false; h.removeCallbacksAndMessages(null); rec?.destroy(); rec = null }

    private fun make() {
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(ctx).also { it.setRecognitionListener(lis) }
    }

    private fun listen() {
        if (!on) return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { rec?.startListening(i) } catch (e: Exception) { again(500, true) }
    }

    private fun again(ms: Long, remake: Boolean = false) {
        if (!on) return
        h.postDelayed({ if (on) { if (remake) make(); listen() } }, ms)
    }

    private val lis = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}
        override fun onPartialResults(b: Bundle?) {
            b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onPartial)
        }
        override fun onResults(b: Bundle?) {
            b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onText)
            again(100)
        }
        override fun onError(e: Int) {
            when (e) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { on = false; onFatal("ต้องอนุญาตไมโครโฟน") }
                SpeechRecognizer.ERROR_CLIENT, SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> again(600, true)
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT, SpeechRecognizer.ERROR_NO_MATCH -> again(100)
                else -> again(400, true)
            }
        }
    }
}
