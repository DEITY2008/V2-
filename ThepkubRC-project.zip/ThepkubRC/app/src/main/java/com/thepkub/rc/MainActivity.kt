package com.thepkub.rc

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    private val vm: AppModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { RcTheme { Root(vm) } }
    }

    override fun onStop() {
        super.onStop()
        vm.estop(); vm.stopListening()   // ออกจากแอป = รถหยุดทันที
    }
}

@Composable
fun Root(vm: AppModel) {
    var ver by remember { mutableIntStateOf(0) }
    val perms = remember {
        buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
        }.toTypedArray()
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ver++ }
    LaunchedEffect(Unit) { launcher.launch(perms) }
    val st by vm.link.state.collectAsState()
    if (st == LinkState.CONNECTED) DriveScreen(vm) else ConnectScreen(vm, ver)
}
