package com.thepkub.rc

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.IOException
import java.util.UUID

enum class LinkState { IDLE, CONNECTING, CONNECTED, FAILED }

/** Bluetooth Classic SPP ไปยัง ESP32 ("RC-Car") ส่งทีละบรรทัด ลำดับไม่สลับ */
@SuppressLint("MissingPermission")
class BtLink(private val ctx: Context, private val scope: CoroutineScope) {
    private val spp: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val _state = MutableStateFlow(LinkState.IDLE)
    val state: StateFlow<LinkState> = _state.asStateFlow()
    private val _name = MutableStateFlow("")
    val name: StateFlow<String> = _name.asStateFlow()
    private var socket: BluetoothSocket? = null
    private val out = Channel<String>(Channel.UNLIMITED)

    fun paired(): List<BluetoothDevice> = try {
        val a = ctx.getSystemService(BluetoothManager::class.java)?.adapter
        a?.bondedDevices?.toList()?.sortedByDescending { it.name == "RC-Car" } ?: emptyList()
    } catch (e: SecurityException) { emptyList() }

    fun connect(d: BluetoothDevice) {
        if (_state.value == LinkState.CONNECTING) return
        scope.launch(Dispatchers.IO) {
            _state.value = LinkState.CONNECTING
            var s: BluetoothSocket? = null
            var connected = false
            try {
                ctx.getSystemService(BluetoothManager::class.java)?.adapter?.cancelDiscovery()
                s = d.createRfcommSocketToServiceRecord(spp)
                s.connect()
                socket = s
                _name.value = d.name ?: d.address
                while (out.tryReceive().isSuccess) { }
                connected = true
                _state.value = LinkState.CONNECTED
                val os = s.outputStream
                val sock = s
                val w = launch {
                    try {
                        for (l in out) { os.write((l + "\n").toByteArray()); os.flush() }
                    } catch (e: IOException) { runCatching { sock.close() } }
                }
                val buf = ByteArray(64)
                try { while (sock.inputStream.read(buf) >= 0) { } } catch (e: IOException) { }
                w.cancel()
            } catch (e: Exception) {
                // connect failed
            } finally {
                runCatching { s?.close() }
                socket = null
                _state.value = if (connected) LinkState.IDLE else LinkState.FAILED
            }
        }
    }

    fun disconnect() { runCatching { socket?.close() } }

    fun send(line: String) { if (_state.value == LinkState.CONNECTED) out.trySend(line) }
    fun drive(l: Int, r: Int) = send("D,$l,$r,$l,$r")
    fun lcd(a: String, b: String = "") = send("P,$a|$b")
}
